// pages/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sum1: '',
    fu: '',
    sum2: '',
    end: '',
    num: '0',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  //获取符号
  h: function (v) {
    //判断是否存在结果，如果存在赋值给sum1
    if (this.data.num != '') {
      this.setData({
        sum1: this.data.num,
        num: ''
      })
    }
    //判断是否存在第二个符号，如果存在计算前面并赋值sum1
    if (this.data.fu != '') {
      this.end();
      if (this.data.num != '') {
        this.setData({
          sum1: this.data.num,
          num: ''
        })
      }
    }
    //获取符号
    var num = v.currentTarget.dataset.value
    this.setData({ fu: num })
  },
  //加减乘除
  d: function (v) {
    var num = v.currentTarget.dataset.value
    console.log(num)
    //判断符号是否存在
    if (this.data.fu == '') {
      //不存在 则累计sum1
      this.data.sum1 = (this.data.sum1 + num)
    }
    else {
      //存在 则赋值sum2
      this.data.sum2 = (this.data.sum2 + num)
    }
    this.setData({
      sum1: this.data.sum1,
      sum2: this.data.sum2,
      num: '',
    })
  },
  //删除
  del_one: function () {
    var sum1 = this.data.sum1;
    var fu = this.data.fu;
    var sum2 = this.data.sum2;
    if (fu == '') {
      sum1 = sum1.substr(0, sum1.length - 1)
      this.setData({
        sum1: sum1
      })
    } else {
      sum2 = sum2.substr(0, sum2.length - 1)
      this.setData({
        sum2: sum2
      })
    }
  },
  //清空
  del: function () {
    this.setData({
      sum1: '',
      fu: '',
      sum2: '',
      end: '',
      num: '0',
    })
  },
  end: function (v) {
    var sum1 = this.data.sum1;
    var fu = this.data.fu;
    var sum2 = this.data.sum2;
    var num = '';
    //判断符号并计算
    if (fu == '*') {
      num = sum1 * sum2
    } else if (fu == '÷') {
      num = sum1 / sum2
    } else if (fu == '+') {
      num = parseInt(sum1) + parseInt(sum2)
    } else if (fu == '-') {
      num = sum1 - sum2
    }
    this.setData({
      sum1: '',
      fu: '',
      sum2: '',
      end: '',
      num: num,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})